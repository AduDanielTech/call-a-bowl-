const Repository = require('./firebaserepo');
class ProductRepository extends Repository{

}
module.exports = new ProductRepository('MENU');