const Repository = require('./firebaserepo');
class LandingRepository extends Repository{

}
module.exports = new LandingRepository('Landing_Page');