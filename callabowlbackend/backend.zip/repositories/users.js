const Repository = require('./firebaserepo');
class UsersRepository extends Repository{

}
module.exports = new UsersRepository('USERS');